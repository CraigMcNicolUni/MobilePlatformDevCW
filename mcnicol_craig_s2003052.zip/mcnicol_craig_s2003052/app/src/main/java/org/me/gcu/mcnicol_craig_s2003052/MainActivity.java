/*  Starter project for Mobile Platform Development in Resit 2022/2023
    You should use this project as the starting point for your assignment.
    This project simply reads the data from the required URL and displays the
    raw data in a TextField
*/

//
// Name                 Craig McNicol
// Student ID           S2003052
// Programme of Study   Graduate Apprenticeship Software Development for Business
//

// UPDATE THE PACKAGE NAME to include your Student Identifier
package org.me.gcu.mcnicol_craig_s2003052;

import androidx.appcompat.app.AppCompatActivity;
//import android.support.v7.app.AppCompatActivity;
//import android.support.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Spinner;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.SplittableRandom;

import org.me.gcu.mcnicol_craig_s2003052.XmlParser;

public class MainActivity extends AppCompatActivity implements OnClickListener
{
    private TextView buildDateDisplay;
    private String buildDateTagContent;

    private Button startButton;
    private EditText editTextAmount;
    private Spinner spinnerFrom;
    private Spinner spinnerTo;
    private String result;

    private TextView resultsTextView;
    private String parseResult;
    private String url1="";
    private String urlSource="https://www.fx-exchange.com/gbp/rss.xml";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Set up the raw links to the graphical components
        buildDateDisplay = (TextView)findViewById(R.id.buildDateDisplay);
        startButton = (Button)findViewById(R.id.startButton);
        startButton.setOnClickListener(this);
        editTextAmount = findViewById(R.id.editTextAmount);
        spinnerFrom = findViewById(R.id.spinnerFrom);
        spinnerTo = findViewById(R.id.spinnerTo);
        resultsTextView = findViewById(R.id.resultsTextView);

    }

    public void onClick(View aview)
    {
        startProgress();
        startButton.setVisibility(View.INVISIBLE);
    }

    public void startProgress()
    {
        // Run network access on a separate thread;
        new Thread(new Task(urlSource)).start();
    } //

    public class Task implements Runnable
    {
        private String url;

        public Task(String aurl)
        {
            url = aurl;
        }
        @Override
        public void run()
        {

            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";


            Log.e("MyTag","in run");

            try
            {
                Log.e("MyTag","in try");
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                while ((inputLine = in.readLine()) != null)
                {
                    result = result + inputLine;
                    Log.e("MyTag",inputLine);

                }
                in.close();
            }
            catch (IOException ae)
            {
                Log.e("MyTag", "ioexception");
            }

            //Get rid of the first tag <?xml version="1.0" encoding="utf-8"?>
            int i = result.indexOf(">");
            result = result.substring(i+1);
            //Get rid of the 2nd tag <rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
            i = result.indexOf(">");
            result = result.substring(i+1);
            Log.e("MyTag - cleaned",result);
            result = result.replace("</rss>", "");
            // add in GBP value since it will be getting sanitised and removed in future XML manipulation
            result = result + ("<item><title>British Pound Sterling(GBP)/British Pound(GBP)</title><description>1 British Pound Sterling = 1 British Pound Sterling</description><category>British Pound Sterling</category></item>");


//          Get the XML publish data via <lastBuildDate> tag
            String buildDateTag = "<lastBuildDate>";
            buildDateTagContent = "";
            int buildDateTagIndex = result.indexOf(buildDateTag);
            if (buildDateTagIndex != -1) {
                int buildDateTagEndIndex = result.indexOf("</lastBuildDate", buildDateTagIndex);
                if (buildDateTagEndIndex != -1) {
                    buildDateTagContent = result.substring(buildDateTagIndex + buildDateTag.length(), buildDateTagEndIndex);
                    Log.e("build date", buildDateTagContent);
                } else {
                }
            }

            Log.e("appended gbp",result);
            parseResult = result;
            //LOWERCASE THE UPPERCASED TAGS </lastBuildDate> and </pubDate>
            result = result.replace("</lastBuildDate>","</lastbuilddate>");
            result = result.replace("</pubDate>","</pubdate>");


            //
            // XML data parsing
            //
            try {
                InputStream inputStream = new ByteArrayInputStream(parseResult.getBytes());
                List<XmlParser.ExchangeRatesItem> exchangeRatesItems = XmlParser.parse(inputStream);
                List<String> currencyCodesList = new ArrayList<>();

                for (XmlParser.ExchangeRatesItem item : exchangeRatesItems) {
                    System.out.println("Title: " + item.title);
                    System.out.println("Currency Code: " + item.currencyCode);
                    System.out.println("Exchange Rate:" + item.exchangeRate);
                    currencyCodesList.add(item.currencyCode);
                    System.out.println("Description: " + item.description);

                }

            }

            catch(Exception e){
                e.printStackTrace();
                }






            MainActivity.this.runOnUiThread(new Runnable()
            {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");
                    buildDateDisplay.setText("Publish Date of Data: " + buildDateTagContent);
                    populateSpinner();

                    Button convertButton = findViewById(R.id.convertButton);
                    convertButton.setOnClickListener(new View.OnClickListener(){
                        public void onClick(View v) {
                            currencyConversionLogic();
                        }
                    });


                }
//             method to populate spinners
                private void populateSpinner(){
                    try {
                        InputStream inputStream = new ByteArrayInputStream(parseResult.getBytes());
                        List<XmlParser.ExchangeRatesItem> exchangeRatesItems = XmlParser.parse(inputStream);
                        List<String> currencyCodesList = new ArrayList<>();
                        for (XmlParser.ExchangeRatesItem item : exchangeRatesItems) {
                            currencyCodesList.add(item.currencyCode);

                        }
                        ArrayAdapter<String> adapter = new ArrayAdapter<>(MainActivity.this,android.R.layout.simple_spinner_item, currencyCodesList);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinnerFrom.setAdapter(adapter);
                        spinnerTo.setAdapter(adapter);
                    }
                    catch(Exception e){
                        e.printStackTrace();
                    }
                }
//              method to get the exchange rate from the xml data using manipulation
                private double getExchangeRate(String selectedCurrencyCode){
                    try{
                    InputStream inputStream = new ByteArrayInputStream(parseResult.getBytes());
                    List<XmlParser.ExchangeRatesItem> exchangeRatesItems = XmlParser.parse(inputStream);
                    for (XmlParser.ExchangeRatesItem item : exchangeRatesItems) {
                        if (item.currencyCode.equals(selectedCurrencyCode)){
                            return item.exchangeRate;
                        }

                    }}
                    catch (Exception e){
                        e.printStackTrace();
                    }
                    return 1.0;

                }
//              method for the logic for the currency conversion
                private void currencyConversionLogic(){
                    String originCurrencyCode = spinnerFrom.getSelectedItem().toString();
                    String wantedCurrencyCode = spinnerTo.getSelectedItem().toString();
                    double amount = Double.parseDouble(editTextAmount.getText().toString());
                    double originExchangeRate = getExchangeRate(originCurrencyCode);
                    double exchangeRate = getExchangeRate(wantedCurrencyCode);
                    double convertedCurrencyValue = (amount / originExchangeRate) * exchangeRate;
                    String convertedCurrencyResults = String.format("%.4f", convertedCurrencyValue);
                    resultsTextView.setText(convertedCurrencyResults);

                }

            });
        }

    }

}