package org.me.gcu.mcnicol_craig_s2003052;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class XmlParser {

    public static class ExchangeRatesItem {
        public String dataBuildDate;
        public String title;
        public String currencyCode;
        public double exchangeRate;
        public String description;

    }
// the below code creates an array list, parses in the xml data and seperates them into items based on the item tag then assigns values to the following variables : title,currency code,
    public static List<ExchangeRatesItem> parse(InputStream inputStream) throws Exception {
        List<ExchangeRatesItem> exchangeRatesItems = new ArrayList<>();

        XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
        XmlPullParser parser = factory.newPullParser();
        parser.setInput(inputStream, null);

        int eventType = parser.getEventType();
        ExchangeRatesItem currentExchangeRateItem = null;

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String tagName = parser.getName();


            switch (eventType) {
                case XmlPullParser.START_TAG:
                    if ("item".equals(tagName)) {
                        currentExchangeRateItem = new ExchangeRatesItem();
                    } else if ("title".equals(tagName)) {
                        if (currentExchangeRateItem != null){
                            currentExchangeRateItem.title = parser.nextText();
                            currentExchangeRateItem.title = currentExchangeRateItem.title.replace("British Pound Sterling(GBP)/" , "");
                            int bracketStartIndex = currentExchangeRateItem.title.indexOf("(");
                            int bracketEndIndex = currentExchangeRateItem.title.indexOf(")");
                            if (bracketStartIndex != -1 && bracketEndIndex != -1 && bracketEndIndex > bracketStartIndex){
                                currentExchangeRateItem.currencyCode = currentExchangeRateItem.title.substring(bracketStartIndex + 1, bracketEndIndex);
                            } else {
                            }
                        }
                    } else if ("description".equals(tagName)) {
                        if (currentExchangeRateItem != null){
                            currentExchangeRateItem.description = parser.nextText();
                            int equalsIndex = currentExchangeRateItem.description.indexOf('=');
                            if (equalsIndex != -1) {
                                String afterEquals = currentExchangeRateItem.description.substring(equalsIndex + 1).trim();
                                int spaceIndex = afterEquals.indexOf(' ');
                                if (spaceIndex != -1) {
                                    String extractedValueString = afterEquals.substring(0, spaceIndex);
                                    double extractedValue = Double.parseDouble(extractedValueString);
                                    currentExchangeRateItem.exchangeRate = extractedValue;
                                }else{}
                            }else{}
                        }
                    }
                    break;

                case XmlPullParser.END_TAG:
                    if ("item".equals(tagName) && currentExchangeRateItem != null) {
                        exchangeRatesItems.add(currentExchangeRateItem);
                        currentExchangeRateItem = null;
                    }
                    break;
            }

            eventType = parser.next();
        }

        return exchangeRatesItems;
    }
}